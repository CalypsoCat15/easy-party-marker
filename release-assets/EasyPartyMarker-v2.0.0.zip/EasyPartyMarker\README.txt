EASY PARTY MARKER 2.0.0
For World of Warcraft Classic Era

WHAT THIS ADDON DOES

- Shows compact colored party markers on the minimap and large map.
- Replaces your player pointer with a directional arrow on both maps.
- Includes a draggable mint button around the minimap.
- Click the mint button to open the customization menu.
- Change party-marker size and color instantly.
- Change player-arrow size and color instantly.
- Includes mint, pink, cyan, lime, yellow, orange, purple, and white.
- Includes a one-click "Lisa's Defaults" reset.
- Keeps the minimap north-up; rotating-map mode is turned off.

LISA'S DEFAULTS

- Party marker: pink, size 10.
- Player arrow: mint/seafoam, medium size.
- Minimap button: right side of the minimap.

REQUIREMENT

Questie must also be installed and enabled. Easy Party Marker uses Questie's
map-position helper to place the custom party markers correctly.

HOW TO INSTALL IT AGAIN

1. Completely exit World of Warcraft.
2. Open the EasyPartyMarker-v2.0.0.zip file.
3. Copy the entire EasyPartyMarker folder into:

   C:\Program Files (x86)\World of Warcraft\_classic_era_\Interface\AddOns

4. If Windows asks whether to merge or replace the folder, choose Yes.
5. Start WoW Classic Era again.
6. On the character-selection screen, click AddOns.
7. Make sure both Questie and Easy Party Marker are checked.
8. Enter the game.

HOW TO USE THE MENU

- Click the mint arrow button around the minimap to open or close the menu.
- Drag the button around the minimap edge to move it.
- Move either size slider to see the change immediately.
- Click a color circle to apply that color immediately.
- Click Lisa's Defaults to restore pink party markers and the mint arrow.
- You can also type /epm to open or close the menu.

PRIVACY

This package contains only addon code, marker textures, and these instructions.
It does not contain character names, account information, messages,
screenshots, or other personal WoW data.
